//A basic C Program to print Hello World.				© Ishav Verma 18/March/2021
//Start
#include<stdio.h> //Including standard input ouput header files from library.
int main(){ 
	printf("Hello Buddy!!");//Here we entered the texted to be printed.
	return 0;//Returning.
} 
//End 